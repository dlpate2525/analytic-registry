> **Historical requirements.** Use [V1.2 requirements](v1.2-requirements.md) for implemented behavior, intended integration, and unresolved policy. The earlier status assessments below remain unchanged.

> **V1.1 update, 9 October 2026:** [Current baseline](v1.1-prototype-baseline.md), [operating review and repair status](v1.1-product-operating-review.md), [simplified foundation](v1.1-model-simplification.md), and [verification](v1.1-verification.md) take precedence where this earlier document differs. The frozen V1 release remains unchanged in its Git tag.

# Analytic Registry — requirements and acceptance criteria

**Version:** `1.0.0-prototype.1` · 8 October 2026 · intended tag `v1.0.0-prototype.1`.

The [V1 baseline](v1-prototype-baseline.md) freezes the local prototype and current extraction handoff. **Prototype** means demonstrated local behavior, not production authorization. **Partial** identifies known gaps. **Design** means future implementation. **V1 handoff** means an offline artifact for manual use, not a live app integration.

Requirements remain valid when implementation is deferred. In particular, classification, PRL, and risk repairs are outside this V1 freeze. Proposed operational targets still need acceptance; approving the prototype does not approve them.

The tables below retain the historical V1 implementation assessment, except requirements explicitly updated for V1.1. Use the V1.1 section for current repairs.

## Functional requirements

| ID | Requirement and acceptance criterion | Current state |
|---|---|---|
| FR-01 | Support Power BI/Fabric, Tableau, and Alteryx. Native unit labels reflect workspace, project, and collection. | Prototype |
| FR-02 | Retain an internal UUID and scoped native identity for each workspace, asset, and connection. Refresh by IDs, never names. | Target schema + V1 extract contract; manual staging retains native IDs; mock uses sample IDs |
| FR-03 | Renames preserve identity; moves update observed membership. Native ID changes require a new object or approved crosswalk. | Design + offline collector tests |
| FR-04 | Use a single Business Owner / Workspace Owner field. Preserve original onboarding LOB and historical declarations. | Prototype displays; full versioning is Design |
| FR-05 | Each asset has at most one current accountable workspace. Preserve orphan identities and multiple observed physical memberships separately. | Prototype one pointer; full associations are Design |
| FR-06 | Store asset-to-asset dependency and asset-to-connection lineage. Do not assume connections belong directly to workspaces. | Prototype direct lineage; dependency table + collection pack |
| FR-07 | Separate business metadata, requested setup, implemented setup, observed evidence, and comparison results. | Prototype + Design |
| FR-08 | Provide Create New, Register Existing, Update Existing, and annual review entry points. Registration selects a discovered record of the correct platform. | Prototype |
| FR-09 | Require purpose, a known owner record, platform, and 1–10 unique Champions on submission. Inactive assignments block; unresolved identities and one Champion warn. | Prototype request checks; production identity eligibility remains Design |
| FR-10 | Show Unverified identity as unresolved. Do not classify it as inactive or invent an extra approval gate. | Partial: request warnings exist; aggregate Champion coverage still conflates unknown and inactive evidence (R03) |
| FR-11 | Capture workspace PII Yes/No, EUCT Yes/No, and exactly one highest applicable DMP tier. Tier 1 is highest, then Tier 2, then Tier 3. | Prototype workspace declarations; asset vocabulary and ranking alignment remain deferred (R08) |
| FR-12 | Standard includes Champion, RW, R, and DS group purposes. Groups inherit workspace accountability; DS suggestions end in `_DS`. | Prototype |
| FR-13 | Distinct group purposes cannot reuse one group. Existing selections resolve to IDs; new names remain prerequisites. | Partial: Existing/New intended-name collision remains possible (R11) |
| FR-14 | Custom requires a reason; Other requires explanation. Permit alternate groups and document alternative security/authentication. | Prototype |
| FR-15 | Custom requires Application Owner or Platform Owner approval. A large group count alone creates no finding. | Prototype Custom approval; separate business access-approval detection misses a group-removal case (R10) |
| FR-16 | Submitted requests are immutable. Corrections create linked drafts and fresh approval context. Superseded requests leave active queues. | Prototype |
| FR-17 | Approval, external implementation, and verification are separate milestones. Verification cannot predate implementation or occur in the future. | Partial: milestones exist; disabling a prior approver can regress a completed request stage (R04) |
| FR-18 | Show one compact My work inbox with setup, accountability, evidence/risk, and annual themes. Counts and filters use the same records. | Partial: inbox exists; overdue annual In progress records are inconsistent across status views (R12) |
| FR-19 | Support platform, business line, severity, ownership, and risk-bucket filtering where applicable. | Prototype |
| FR-20 | Show Workspace and Asset mapping columns where real relationships exist; retain missing associations explicitly. | Prototype |
| FR-21 | Asset assessments capture release, purpose, audience, people, references, PRL inputs, classifications, reviewer, date, status, and outcome. | Prototype |
| FR-22 | Initial production release and material source, credential, access, processing, or audience changes require assessment. Minor presentation changes are exempt. | Guidance in prototype; release enforcement is Design |
| FR-23 | Reject invalid dates, unknown/inactive assessors, negative counts, and unsafe reference URL schemes. Historical assessments cannot alter current classifications. | Partial: validation and previous-release guards exist; same-release backdating and rejected projection defects remain (R06–R07) |
| FR-24 | Record an approved PRL manually and retain readiness inputs. Calculate no score. Preserve historical illustrative values separately. | Confirmed requirement; legacy scoring-oriented fields and approval evidence remain unaligned. Repair deferred for V1 (R08) |
| FR-25 | Risk buckets are outputs, not onboarding questions. Preserve all 11 specified buckets and their meanings. | Prototype fixtures; production evaluator is Design |
| FR-26 | Pending requested change differs from drift. Preserve unrelated drift even when a request is pending. | Partial: a pending Champion change can hide unrelated observed drift (R09) |
| FR-27 | Require usable, complete, sufficiently fresh evidence for conclusive comparison. Unknown freshness/completeness yields Unable to Verify. | Prototype workspace metadata; dataset-level Design |
| FR-28 | Detection capability is Available, Partial, Manual Review Required, or Not Available, distinct from result. | Prototype |
| FR-29 | Repeated detection must update one finding lifecycle using stable rule, object, and issue identity. Count distinct affected objects separately. | Logical schema; mock fixtures |
| FR-30 | Prioritize no active Champions, no active owner, orphaned workspace, orphaned asset, and unassociated connection reviews. Severity can increase with impact. | Partial: mock queues exist; unresolved versus disabled coverage needs a shared evaluator (R03) |
| FR-31 | A business user can respond only to assigned business work. Administrative actions and verification are protected. Completed cases remain immutable. | Partial: local review guards exist; annual actor binding and request draft ownership checks remain incomplete (R05). No production authorization |
| FR-32 | Closure requires resolution, valid verification, exact evidence, and Platform Manager, Platform Team, or Platform Owner approval. | Prototype, automated checks |
| FR-33 | Close only the explicitly linked findings. Never alter platform state as a consequence of a review status change. | Prototype |
| FR-34 | Annual review recipients are selected Champions, not all RW/R members. Freeze the review context and questionnaire version. | Prototype snapshot; delivery/versioned questions are Design |
| FR-35 | Every annual response requires Application Owner or Platform Owner approval. Exceptions produce linked follow-up. | Prototype |
| FR-36 | Annual completion with open follow-up is permitted after owner approval. Resubmission must preserve the existing follow-up investigation. | Prototype |
| FR-37 | Administrator operations use Collect, Assess, Prepare, Execute, Verify. All platform execution stays external and human approved. | Prototype guidance; no execution integration |
| FR-38 | Persist local edits across reload. Failed saves must not show success. Malformed data and cross-tab conflicts must not silently overwrite saved records. | Prototype, automated checks |
| FR-39 | Offer export and recoverable reset for local prototype data. Never reset user data as part of testing. | Prototype |
| FR-40 | Provide the business/product definition, relationship diagrams, complete column dictionary, audit report, and collection mapping contract. | V1 documents and workbook. The target model has 53 tables / 602 columns; the extract has nine tables / 117 columns |
| FR-41 | DS groups create and maintain workspace data connections through approved platform-specific capabilities. The suffix alone confers no access. | Confirmed purpose; native mappings require platform verification |
| FR-42 | Permit self-approval when the authenticated person holds the required role and scope. Apply all evidence, state, and revision checks. | Prototype allows eligible same-person approval; production authorization is Design |
| FR-43 | Keep six calendar months of business-metadata history. Preserve current records, open-work evidence, active approval dependencies, and native-ID mappings. | Confirmed duration; controlled cleanup is Design |

## V1 extraction requirements

| ID | Requirement and acceptance criterion | Current state |
|---|---|---|
| FR-44 | Supply an empty workbook with Guide, Source_Map, Column_Dictionary, three platform output tabs, and nine import tables. Keep 117 import columns in exact contract order. | V1 handoff; no populated platform data or Excel formulas |
| FR-45 | Load SQL staging manually. Validate records before review; apply approved data through the manual database process. | Staging, validation, and match scripts supplied; no live SQL execution or automated registry importer |
| FR-46 | Match exact normalized SourceEmail to Graph Mail in the configured tenant. Require one distinct user; review duplicate/conflicting rows. Never substitute UPN or display name. | V1 SQL matching contract, separate from the app's mock person status |
| FR-47 | Preserve scoped native principal IDs, object-role references, directory IDs, raw email, UPN, and account state separately. Send all unresolved cases to Platform Manager. Keep resolved-disabled distinct from no match. | V1 Platform_Users, Directory_Users, Object_Users and review result sets |
| FR-48 | Query SQL Server copies of Alteryx Gallery and Service data through explicit adapter views. Preserve unknown current ownership; authorship does not prove ownership. | V1.1 SQL query and mapping guide; installed 2025.2 export shape requires validation |
| FR-49 | Preserve existing RunKey, ObservedAt, and manifest behavior. Keep directory-run context separate. Do not add RunDate or redesign runs for V1. | V1 contract retained; future timestamp consistency work remains R14 |

## Nonfunctional requirements

| ID | Requirement | Verification / status |
|---|---|---|
| NFR-01 | Use five main sections and fewer than six steps per process. Disclose detailed context progressively. | Current requests 5, assessments 5, reviews 3, annual 3, external administration 5 |
| NFR-02 | Use readable labels, visible focus, keyboard operation, accessible names, text alternatives, and status text independent of color. | Improved labels, focus, skip link, and status colors. Formal WCAG 2.2 AA audit remains required |
| NFR-03 | Use a fixed 1366 × 768 tablet landscape canvas. Scale proportionally within the player. Scroll long pages and wide tables internally. | [V1.1 layout contract](v1.1-canvas-layout.md) supersedes earlier narrow-screen reflow. Power Apps player validation remains pending. |
| NFR-04 | Enforce authentication, record-level authorization, role eligibility, and scope server-side. Permit self-approval when the actor holds the required role. | Design. View switch is a simulation; no blanket independent-approver requirement |
| NFR-05 | Store no passwords, tokens, raw credential strings, or secret values. Collect only approved metadata. | Prototype reference fields; collector allowlists; production classification review required |
| NFR-06 | Use parameterized queries and managed credentials. Collectors run read-only with the minimum approved scope. | Collection pack design; no live connections configured |
| NFR-07 | Use stable keys, foreign keys, unique constraints, append-only evidence, and transactional multi-row commands. | Logical schema. Browser store is not a production database |
| NFR-08 | Use optimistic concurrency for mutable production records. Reject outdated revisions and stale approval context. | Prototype storage conflict and approval binding; database RowVersion proposed |
| NFR-09 | Store technical timestamps in UTC and display the zone. Treat business dates as calendar dates. Leap-day annual calculations remain valid. | Shared date checks; legacy mock timestamps require migration in production |
| NFR-10 | Track run, dataset, scope, collector version, row counts, completeness, failures, and lineage provenance. | Collection contract + schema |
| NFR-11 | Complete/partial/failed extracts must not be confused. Process removal only after complete comparable scope and approved absence rules. | Design + offline collection tests |
| NFR-12 | Loading, empty, unresolved, error, and failed-save states must be explicit. Avoid silently replacing user records with demo data. | Improved local recovery and empty states; production telemetry pending |
| NFR-13 | Every decision records actor, time, target, revision, evidence, and outcome. Apply the six-month history treatment in the decision register. | Local receipts; protected production storage and cleanup are Design |
| NFR-14 | Production filters and counts must run in the data service with defined grains; do not depend on loading the full estate into Power Apps. | Design; approve estate size and performance targets before load testing |
| NFR-15 | Proposed performance target: common production galleries return within 2 seconds at agreed p95 load. Define record counts, network, and concurrency first. | Proposed, not measured or committed |
| NFR-16 | Define backup, recovery, monitoring, deployment rollback, support ownership, and service hours before production. | Open operating-model decisions; no SLA invented |
| NFR-17 | Reusable fields and central validation must keep labels, rules, table dictionaries, and workflows consistent. | Shared person, evidence, groups, workflow, and dictionary modules |
| NFR-18 | Maintain regression checks for state transitions, approval binding, identity, date boundaries, data preservation, and partial evidence. | Recorded suites and browser walkthroughs; known counterexamples remain in the repair backlog |

## V1 prototype acceptance

1. Identify the prototype and current handoff with version `1.0.0-prototype.1` and intended tag `v1.0.0-prototype.1`.
2. Keep app references, workbook layouts, SQL staging, and document scope aligned.
3. Record the checks actually performed in the [verification record](verification.md).
4. Preserve known defects and untested live dependencies in the [repair backlog](github-review-and-repair-plan.md).

This acceptance freezes a prototype. It does not mark deferred requirements as implemented or approve the proposed operating settings.

## Future production acceptance gates

1. Approve policy terms, role mappings, source scopes, and evidence freshness.
2. Validate the first platform extracts against the shared contract and scoped native identities.
3. Deploy transactional storage and enforce authorization outside the client.
4. Prove idempotent refresh, version retention, conflict detection, and complete-scope reconciliation.
5. Complete accessibility, security, performance, backup, and user acceptance testing with agreed operating targets.

The prototype remains suitable for product review within its documented limits. Production gates must pass before live operational reliance. The [decision register](decision-register.md) separates confirmed choices, future design, proposed operating settings, and delivery checks.

## V1.1 requirement changes and evidence

| Requirement | V1.1 status |
|---|---|
| Define each input field for all three platforms, including unknown and uncollected behavior. | Implemented in contract, workbook, and app dictionary; installed mappings require validation. |
| Preserve native keys across monthly rename, movement, and incomplete collections. | Reference logic and regression checks implemented. Production acceptance and key ledger remain unimplemented. |
| Do not overwrite business declarations with platform ownership. | Authority contract defined; no live importer exists. |
| Record one Person with source-scoped accounts and binding history. | Proposed typed foundation; database migration is not deployed. |
| Retain prior approved classifications after an older or rejected assessment. | Implemented and regression checked. |
| Bind request and annual actions to the current prototype actor. | Implemented in UI and command guards; production authentication remains required. |
| Preserve approval validity after later directory changes. | New decisions capture eligibility evidence. Legacy receipts retain historical facts without invented eligibility proof. |
| Show evidence-closure approval and unlinked completed delivery in My work. | Implemented; registry import/linking remains an explicit next action. |
| Separate disabled, unresolved, duplicate, and non-person identity evidence. | Reference matcher and SQL preview aligned; SQL engine execution is pending. |
| Keep fewer than six main sections and process steps. | Five main sections retained; existing guided processes retained. |
| Use white backgrounds with purple and coral accents. | Implemented; status text remains explicit. |
| Use 1366 × 768 fixed landscape coordinates with proportional scaling. | Implemented locally; internal scrolling and unchanged logical layout checked across five viewport sizes. |

Nonfunctional boundaries remain unchanged: production requires authenticated commands, transaction safety, SQL constraints, authorization, monitoring, and recovery. Local tests do not establish those controls.
